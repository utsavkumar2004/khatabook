const hisaabModel = require("../models/hisaabModel");
const userModel = require("../models/userModel");

module.exports.createPageController = async function (req, res, next) {
  res.render("create");
};



module.exports.readHisaabController = async function (req, res, next) {

  return res.render("hisaab");
};

module.exports.readVerifiedHisaabController = async function (req, res, next) {

  return res.render("hisaab");
};


