const jwt = require("jsonwebtoken");
const userModel = require("../models/userModel");
const bcrypt = require("bcrypt");

module.exports.homepageController = function (req, res) {
  let message = req.flash("error");
  res.render("index", { isloggedin: false, });
};



module.exports.profileController = async function (req, res, next) {


  res.render("profile",);
};

module.exports.registerPageController = async function (req, res, next) {
  res.render("register", { isloggedin: false });
};
