const express = require("express");
const router = express.Router();

const {
  homepageController,
  logoutController,
  profileController,
  registerPageController,
} = require("../controllers/indexController");

router.get("/", homepageController);
router.get("/logout", logoutController);
router.get("/register", registerPageController);
router.get("/profile", profileController);

module.exports = router;
