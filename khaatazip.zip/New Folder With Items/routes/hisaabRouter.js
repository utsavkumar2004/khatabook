const express = require("express");
const router = express.Router();


const {
  createPageController,
  readHisaabController,
  readVerifiedHisaabController,
} = require("../controllers/hisaabController");

router.get("/create", createPageController);
router.get("/view/:id", readHisaabController);
router.get("/:id", readVerifiedHisaabController);

module.exports = router;
